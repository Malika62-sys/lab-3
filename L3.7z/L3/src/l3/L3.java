package l3;

import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.util.*;


class L1
{
	protected String sentence;
	public L1()
	{
		sentence = "";
	}
	public L1(String text)
	{
		sentence = text;
	}
	
	String findCenter()
	{
		int middle = sentence.length()/2; // ищем центр
        int startIndex = middle, endIndex = middle; // пусть изначально начальный индекс и последний равны середине
        /*
        Пока символ не равен 0 (начало предложения) и не равен пробелу - уменьшаем начальный индекс на 1
         */
        while (startIndex != 0 && sentence.charAt(startIndex) != ' '){
            --startIndex;
        }
        /*
        Пока символ не равен длине предложения (конец предложения) и не равен пробелу - увеличиваем последний индекс на 1
         */
        while (endIndex != sentence.length() && sentence.charAt(endIndex) != ' '){
            ++endIndex;
        }
        /*
        Вывод на экран результата
         */
        if(startIndex == endIndex)
        {
            return " ";	//Центр в предложении пробел;
        }
        else
        {
            return sentence.substring(startIndex, endIndex).trim();
        }
	}
	
	String tenPercentChars()
	{
		String lowerCaseSentence = sentence.toLowerCase(); // предложение, toLowerCase() - все буквы маленькие
        double tenPercent = lowerCaseSentence.length()*0.1; //ищем 10 %
        int count = 0; //количество символов
        String str = "";
        int aa[] = new int[2000];	// Ассоциативный массив
        for (int i=0; i<2000; i++)
        {
        	aa[i] = 0;
        }
        String lcs = lowerCaseSentence;
        for (int i = 0; i < lcs.length(); i++) {
            aa[lcs.charAt(i)]++;
        }
        for (int i=0; i<2000; i++)
        {
        	if (aa[i]>tenPercent)
        	{
        		str += "'" + (char)i + "' ";
        	}
        }
        return str;
	}
	
	String[] words()
	{
		String[] arrayWords = sentence.split(" "); //создаем масив слов, разделенных пробелами
		List<String> result = new ArrayList<String>();
	    for (int i = 1; i < arrayWords.length; i++) {
	        //если длина первого слова == длине i-го, то выводим слово в консоль
	        if(arrayWords[0].length() == arrayWords[i].length()){
	        	result.add(arrayWords[i]);
	        }
	    }
	    
	    return result.toArray(new String[result.size()]);
	}
}


interface ActionInteface
{
	String getComment();
	String getName();
	void exec() throws IOException;
}

class LabA extends L1 implements ActionInteface
{
	
	String name,comment;
	
	LabA()
	{
		name = "Центральное слово";
		comment = "Выбор слова, находящегося в центре введённого текста";
	}
	
	public void exec() throws IOException {
		sentence = Menu.br.readLine();
		Menu.bw.write(findCenter());
		Menu.bw.flush();
	}

	@Override
	public String getComment() {
		// TODO Auto-generated method stub
		return comment;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	
}

class LabB extends L1 implements ActionInteface
{
	String name,comment;
	
	LabB()
	{
		name = "Частые символы";
		comment = "Получение списка символов, количество которых не меньше 10% от длины введённого текста";
	}
	
	@Override
	public void exec() throws IOException {
		sentence = Menu.br.readLine();
		Menu.bw.write(tenPercentChars());
		Menu.bw.write('\n');
		Menu.bw.flush();
	}
	 
	@Override
	public String getComment() {
		// TODO Auto-generated method stub
		return comment;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	
}

class LabC extends L1 implements ActionInteface
{
	
	String name,comment;
	
	LabC()
	{
		name = "Длина первого слова";
		comment = "Перечисление всех слов, равных по длине первому";
	}
	
	@Override
	public void exec() throws IOException {
		sentence = Menu.br.readLine();
		String[] result = words();
		for (int i=0; i<result.length; i++)
		{
			Menu.bw.write(result[i] + " ");
		}
		Menu.bw.write('\n');
		Menu.bw.flush();
	}

	@Override
	public String getComment() {
		// TODO Auto-generated method stub
		return comment;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	
}

class Menu
{
	private static ActionInteface[] items = new ActionInteface[] {new LabA(), new LabB(), new LabC()};
	static Scanner scanner;

	static protected BufferedReader br;
	static protected BufferedWriter bw;
	
	private static int showReadingDialog(int index)
	{
		System.out.println("Ввод данных");
		System.out.println("1. Из консоли");
		System.out.println("2. Из файла");
		System.out.println("3. Назад");
		int act;
		
		if (scanner.hasNextInt())
		{
			act = scanner.nextInt();
                                
			switch (act)
			{
				case 1 : br = new BufferedReader(new FileReader(FileDescriptor.in));; return 1;
				case 2 : try
						{
							if (scanner.hasNext())
							{
								br = new BufferedReader(new FileReader(scanner.next())); return 1;
							}
							else
							{
								return 0;
							}
						}
						catch (IOException e)
						{
							return 0;
						}
				case 3 : return -1;
				default : return 0;
			}
		}
		return 0;
	}
	
	private static int showSavingDialog(int index)
	{
		System.out.println("Вывод данных");
		System.out.println("1. В консоль");
		System.out.println("2. В файл");
		System.out.println("3. Назад");
		
		int act;

		if (scanner.hasNextInt())
		{
			act = scanner.nextInt();
			switch (act)
			{
				case 1 : bw = new BufferedWriter(new FileWriter(FileDescriptor.out)); return 1;
				case 2 : try
						{
							if (scanner.hasNext())
							{
								bw = new BufferedWriter(new FileWriter(scanner.next())); return 1;
							}
							else
							{
								return 0;
							}
						}
						catch (IOException e)
						{
							return 0;
						}
				case 3 : return -1;
				default : return 0;
			}
		}
		return 0;
	}
	
	static void showRoot()
	{
            scanner = new Scanner(System.in);           
                
                          
		for (int i=0; i<items.length; i++)
		{
			System.out.println((i+1) + ". " + items[i].getName());
	}
		System.out.println(items.length+1+". Выход");
		
		System.out.println("Введите соответствующее число");
		scanner = new Scanner(System.in);
		if (scanner.hasNextInt())
		{
			int index = scanner.nextInt();
			index--;
			if (index<0 || index>=3)
			{
				System.out.println("Выход");
			}
			else
			{
				pickItem(index);
				showRoot();
			}
		}
		else
		{
			System.out.println("Неправильный ввод");
			showRoot();
		}
	}
	
	private static void showItem(int index)
	{
		System.out.println(items[index].getName());
		System.out.println(items[index].getComment());
	}
	
	private static void pickItem(int index)
	{
		int result = showReadingDialog(index);
		while (result==0)
		{
			result = showReadingDialog(index);
		}
		if (result==-1)
		{
			return;
		}
		result = showSavingDialog(index);
		while (result==0)
		{
			result = showSavingDialog(index);
		}
		if (result==-1)
		{
			return;
		}
		
		showItem(index);
		
		try {
			items[index].exec();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return;
		}
	}
}
public class L3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        		Menu.showRoot();
		Menu.scanner.close();
    }
    
}

